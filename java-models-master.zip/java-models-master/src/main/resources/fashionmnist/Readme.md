This dataset is distributed under MIT License and presented in next paper.
Fashion-MNIST: a Novel Image Dataset for Benchmarking Machine Learning Algorithms. Han Xiao, Kashif Rasul, Roland Vollgraf. arXiv:1708.07747

The data was downloaded from the FashionMnist Repository
https://github.com/zalandoresearch/fashion-mnist/tree/master/data/fashion

